

public class Queue_Cao {

    private int numberOfItems;
    private final int[] pila;
    private final int sizeOfQueue;
    
public Queue_Cao    (int size){
        sizeOfQueue = size;
        pila = new int[sizeOfQueue];
    }    

public void showQ(){
        
        for(int i = 0; i < sizeOfQueue; i++){
            System.out.printf("Queue[%d] = %d\n", i, pila[i]);
        }   
    }
  
private boolean emptyQ(){
        if(numberOfItems == 0){
        System.out.println("The Queue is empty");
        return true;
        } else {
        return false;
        }
    }

private boolean fullQ(){
        if(numberOfItems == sizeOfQueue){
            System.out.println("The Queue is full");
            return true;
        } else {
        return false;
        }
    }
public boolean enQ(int num){
        System.out.print("Trying to enqueue " + num + "... ");
        if(! fullQ()){
            pila[numberOfItems] = num;
            System.out.println("Added " + num);
            numberOfItems++;
            return true;
        } else {
            System.out.println("Failed to enqueue " + num);
            return false;
        }
    }


 public int pump(){
        return pila[0];
    } 

    public int stum(){
        return pila[numberOfItems];
    }
}

class Main{
    public static void main(String[] args) {
       Queue_Cao list = new Queue_Cao(10);

		list.enQ(5);
		list.enQ(13);
		list.enQ(12);
		list.enQ(18);
		list.enQ(55);
		list.enQ(6);
                list.enQ(23);
		list.showQ();
		
    }
    
}
 