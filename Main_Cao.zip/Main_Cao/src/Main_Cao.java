
class Main_Cao{
    public static void main(String[] args) {
       Queue_Cao aq = new Queue_Cao(10);

		aq.enQ(5);
		aq.enQ(13);
		aq.enQ(12);
		aq.enQ(18);
		aq.enQ(55);
		aq.enQ(6);

		aq.showQ();
		System.out.println( "PeekRear: " + aq.stum() );
    }
    
}
